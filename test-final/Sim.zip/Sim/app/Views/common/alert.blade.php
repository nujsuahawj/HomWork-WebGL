<div class="alert alert-{{ $type }}">{!! balanceTags($message) !!}</div>
